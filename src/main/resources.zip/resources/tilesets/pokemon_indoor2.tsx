<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="innenraum" tilewidth="16" tileheight="16" tilecount="1426" columns="31">
 <image source="innenraum.png" width="496" height="736"/>
</tileset>
