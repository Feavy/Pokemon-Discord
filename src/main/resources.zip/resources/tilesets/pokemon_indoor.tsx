<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="pokemon_indoor" tilewidth="16" tileheight="16" tilecount="12288" columns="192">
 <image source="pokemon_indoor.png" width="3072" height="1024"/>
</tileset>
